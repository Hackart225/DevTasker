#!/bin/bash
# Usage: ./create_repo.sh <repo-name>
if [ -z "$1" ]; then
  echo "Specify repo name"
  exit 1
fi
gh repo create "$1" --public --source=. --remote=origin --push
